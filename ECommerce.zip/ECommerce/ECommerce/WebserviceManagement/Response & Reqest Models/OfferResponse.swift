//
//  OfferResponse.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation

struct OfferResp: Codable {
    var statusCode: Int?
    var status: Bool?
    var message: String?
    var response: OfferArrayResponse?
}

struct OfferArrayResponse: Codable {
    var offers: [Offer]?
}

struct Offer: Codable {
    var offerId : String?
    var offerImage: String?
}
