//
//  BannerResponse.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation

struct BannerResp: Codable {
    var statusCode: Int?
    var status: Bool?
    var message: String?
    var response: BannerArrayResponse?
}

struct BannerArrayResponse: Codable {
    var banners: [Banner]?
}

struct Banner: Codable {
    var bannerId : String?
    var bannerImage: String?
}
