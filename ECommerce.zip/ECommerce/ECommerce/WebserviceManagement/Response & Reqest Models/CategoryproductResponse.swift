//
//  CategoryproductResponse.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation
struct CategoryproductResponse: Codable {
    var statusCode: Int?
    var status: Bool?
    var message: String?
    var response: CategoryBasedProduct?
}

struct  CategoryBasedProduct: Codable {
    var categoryBasedProducts: [CategorProduct]?
}

struct CategorProduct: Codable {
    var categoryId : String?
    var categoryImage: String?
}
