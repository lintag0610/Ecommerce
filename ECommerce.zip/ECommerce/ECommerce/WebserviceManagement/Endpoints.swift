//
//  Endpoints.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation
import Alamofire

// Just for Demo purpose - Ecommerce APP
struct EndPoint {
    static var baseURLString: String {
        return "http://ecommerce.com/api"    // Something like this would be baseURL of ecommerce APP - Just for Demo
    }
}

class EcommerceEndPoint {
    enum Router<T: Codable>: URLRequestConvertible {
        
        case getCategories(String)
        case getBanners(String)
        case getOffers(String)
    
        
        // All the GET Methods for Request
        var method: HTTPMethod {
            switch self {
            case .getCategories,.getBanners, .getOffers:
                return .get
            }
        }
         // API Path names can be written here
         //  Value is parameter value -
        // Values written here are just for demo purpose of Whiterabbit, since no APIS are provided but needed a WEbService Layer
        
        var path: String {
            switch self {
            case .getCategories(let value):
                return "categorybased/products=" + value
            case .getBanners(let value):
                return "banners/list=" + value
            case .getOffers(let value):
                return "offers/list=" + value
            }
        }
        

        
        func asURLRequest() throws -> URLRequest {
            let url = URL(string: EndPoint.baseURLString)
            guard let urlWithPath = url?.appendingPathComponent(path).absoluteString.removingPercentEncoding else { return URLRequest(url: URL(string: "")!) }
            guard let encoded = urlWithPath.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed)else {
                fatalError("error url")
            }
            let urlOfAPI = URL(string: encoded)
            var urlRequest = URLRequest(url: urlOfAPI!)
            urlRequest.httpMethod = method.rawValue
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            urlRequest.setValue("keep-alive", forHTTPHeaderField: "Connection")
            switch self {
            case .getCategories(let parameters), .getBanners(let parameters), .getOffers(let parameters):

                self.setBody(parameters: parameters as? T, toRequest: &urlRequest)
            }
            
            return urlRequest
            
        }
        
        // Parameters needs to be passed here
        private func setBody(parameters: T?, toRequest request: inout URLRequest) {
            do {
                guard let params = parameters else {return}
                let encodedData = try JSONEncoder.init().encode(params)
                request.httpBody = encodedData
                
            } catch {
                // Error Handling
            }
        }
    }
}
