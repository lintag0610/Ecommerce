//
//  ECommerceWebServiceManager.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation
public typealias CompletionHandlerWithHeader = (_ header: Any?, _ result: Any?, _ error: ErrorHandler?) -> Void

class ECommerceWebServiceManager {
    static let shared = ECommerceWebServiceManager()
    private init() {}
    
    // Products
    func getCategories(parameter: String, completionHandler: @escaping CompletionHandlerWithHeader) {
        do {
            WebserviceManager.request(withRequest: try EcommerceEndPoint.Router<String>.getCategories(parameter).asURLRequest(), resultModelType: CategoryproductResponse.self) { (header, result, error) in
                completionHandler(header, result, error)
            }
        } catch let exception {
            completionHandler([], nil, exception as? ErrorHandler)
        }
    }
    // Carousel
    func getOffers(parameter: String, completionHandler: @escaping CompletionHandlerWithHeader) {
        do {
            WebserviceManager.request(withRequest: try EcommerceEndPoint.Router<String>.getCategories(parameter).asURLRequest(), resultModelType: OfferResp.self) { (header, result, error) in
                completionHandler(header, result, error)
            }
        } catch let exception {
            completionHandler([], nil, exception as? ErrorHandler)
        }
    }
    //Banners
    func getBanners(parameter: String, completionHandler: @escaping CompletionHandlerWithHeader) {
        do {
            WebserviceManager.request(withRequest: try EcommerceEndPoint.Router<String>.getCategories(parameter).asURLRequest(), resultModelType: BannerResp.self) { (header, result, error) in
                completionHandler(header, result, error)
            }
        } catch let exception {
            completionHandler([], nil, exception as? ErrorHandler)
        }
    }
}
