//
//  WebserviceManager.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation
import Alamofire

public typealias CompletionHandler = (_ header: Any?, _ result: Any?, _ error: ErrorHandler?) -> Void
open class WebserviceManager {
    
    static var sessionManger = { () -> SessionManager in
    
        var sessionManager: SessionManager! //Session mangaer will not be empty.
        sessionManager = SessionManager.default
        return sessionManager
    }
    static var manager = WebserviceManager.sessionManger()
    public static func request<T: Decodable>(withRequest request: URLRequest, resultModelType: T.Type, withCompletionHandler handler: @escaping CompletionHandler) {
        
    
        //If WiFi/Mobile network is not connected the network error is send back
        guard Connectivity.isConnectedToInternet else {
            handler(nil, nil, ErrorHandler.init(message: "No Network", errorType: ErrorType.InternetError))
            return
        }
        
        WebserviceManager.manager.request(request).validate().responseData { response in

            switch response.result {
            case .success:
                guard let headerDictionary = response.response?.allHeaderFields else {
                    handler(nil, nil, ErrorHandler.init(message: "Error in Header", errorType: ErrorType.HeaderError))
                    return
                }
                guard let json = response.result.value else {
                    //If response is success but  doesn't have data default error object is send back
                    handler(nil, nil, ErrorHandler.init(message: "No Data", errorType: ErrorType.NoDataAvailable))
                    return
                }
              
                do {
                    //Try decoding the data received from server to the given model type
                        let result = try JSONDecoder.init().decode(resultModelType, from: json)
                        handler(headerDictionary, result, nil)
                    
                  
                } catch let exception {
                    handler(nil, nil, ErrorHandler.init(withError: exception))
                }
            case .failure(let error):
                guard let json = response.data else { //if response doesn't have error data then default error object is send back
                    handler(nil, nil, ErrorHandler.init(withError: error))
                    return
                }
               
                    do {
                        let resultOfResponse = try JSONSerialization.jsonObject(with: json, options: .mutableContainers) as? [String: Any]
                        let code = resultOfResponse?["statusCode"] as? Int
                        // Success
                        if code == 200 {
                            handler(nil, resultOfResponse, nil)
                        }
                        else {
                            handler(nil, nil, ErrorHandler.init(code: code, message: "Response status code not 200", errorType: nil))
                        }
                    } catch let myJSONError {
                        // Data Parsing Error
                        handler(nil, nil,ErrorHandler(withError: myJSONError))
                    }
                   
                
            }
        }
    }
    
}

// Error handlers
public class ErrorHandler: Error {
    var errorCode: Int?
    var messageCode: String?
    var errorType: ErrorType?
    var errorMessage: String?

    
    public init(message: String, errorType: ErrorType? = nil) {
        self.errorMessage = message
        self.errorType = errorType
    }
    public init(code: Int?, message: String, errorType: ErrorType? = nil) {
        self.errorCode = code
        self.errorMessage = message
        self.errorType = errorType
    }
  public init(withError error: Error) {
   let recievedError: NSError = error as NSError
  self.errorCode = recievedError.code
  self.errorMessage = recievedError.localizedDescription
}
}
public enum ErrorType {
    case InternetError
    case ServerError
    case HeaderError
    case NoDataAvailable
}
