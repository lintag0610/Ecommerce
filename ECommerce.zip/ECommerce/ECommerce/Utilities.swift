//
//  Utilities.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation

