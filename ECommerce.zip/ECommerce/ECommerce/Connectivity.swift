//
//  Connectivity.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation
import Alamofire

class Connectivity {
    class var isConnectedToInternet: Bool {
            return NetworkReachabilityManager()?.isReachable ?? false
        }
        
}
