//
//  HomeViewController.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import UIKit

class HomeViewController: UIViewController {
  
    @IBOutlet var homeTableView: UITableView!
    lazy var viewModel: HomeViewModel = {
        var vm = HomeViewModel()
        vm.UpdateUIDelegate = self
        return vm
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.fetchDataForHomeScreen(loadFromAPI: false)
        homeTableView.estimatedRowHeight = 200
        homeTableView.rowHeight = UITableView.automaticDimension
        // Do any additional setup after loading the view.
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
}
extension HomeViewController:  HomeUIUpdater {
    func loadHomeView() {
        self.homeTableView.reloadData()
    }
    
}
extension HomeViewController:  UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {

       return 1
   }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

      
       return  3

   }
  
   // You can swipe at each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "HomeOfferCell", for: indexPath) as! HomeCarouselCell
            cell.offerList = viewModel.offerList
            cell.selectionStyle = .none
            cell.productCollectionView.reloadData()
            return cell
        }
        else if indexPath.row == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "HomeOfferCell", for: indexPath) as! HomeCarouselCell
            cell.bannerList = viewModel.bannerList
            cell.selectionStyle = .none
            cell.productCollectionView.reloadData()
            return cell
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "HomeCategoryCell", for: indexPath) as! HomeCategoryCell
            cell.selectionStyle = .none
                       print(viewModel.productsCategoryBased)
            cell.categorylist = viewModel.productsCategoryBased
            cell.productCollectionView.reloadData()
            if let flowLayout = cell.productCollectionView?.collectionViewLayout as? UICollectionViewFlowLayout {
               flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
            }
            
        //cell.productCollectionView.layoutIfNeeded()
    
            return cell
            
        }
    }
   
}
