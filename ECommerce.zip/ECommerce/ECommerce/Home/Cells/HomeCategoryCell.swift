//
//  HomeCategoryCell.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import UIKit
import Kingfisher

class HomeCategoryCell: UITableViewCell {
    @IBOutlet weak var productCollectionView: UICollectionView!
    var categorylist: [CategorProduct] = []
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
extension HomeCategoryCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        return categorylist.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryListCell", for: indexPath) as? CategoryListCell
        {
            
            let imageURL = categorylist[indexPath.row]
            setUpImages(imageUrl:URL(string: imageURL.categoryImage!)!, imageView: cell.categoryImage)
            return cell
        }
        return UICollectionViewCell()
       
    }
    func setUpImages(imageUrl: URL, imageView: UIImageView) {
       
        let scale = UIScreen.main.scale
        let resizingProcessor = DownsamplingImageProcessor(size: CGSize(width: imageView.bounds.size.width * scale, height: imageView.bounds.size.height * scale))
        imageView.kf.indicatorType = .none
        imageView.kf.setImage(with: imageUrl, placeholder: UIImage(named: "") , options: [
                .processor(resizingProcessor),
                .scaleFactor(UIScreen.main.scale),
                .cacheOriginalImage
            ]) { (_) in
            }
        
    }
   
}
