//
//  HomeCarouselCellTableViewCell.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import UIKit
import UPCarouselFlowLayout
import Kingfisher

enum HomeCellType {
    case HomeBanner
    case HomeOffer
}

class HomeCarouselCell: UITableViewCell {
    @IBOutlet weak var productCollectionView: UICollectionView!
    var imageArray: [URL] = []
    var offerList : [Offer]? {
        didSet {
            imageArray = []
            for item in offerList ?? [] {
                imageArray.append(URL(string: item.offerImage ?? "")!)
            }
        }
    }
    var bannerList : [Banner]? {
        didSet {
            imageArray = []
            for item in bannerList ?? [] {
                imageArray.append(URL(string: item.bannerImage ?? "")!)
            }
        }
    }
    
    var celltype: HomeCellType = .HomeBanner
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let layout = UPCarouselFlowLayout()
        layout.itemSize = CGSize(width: screenWidth - 60 , height: 220)
        layout.sideItemScale = 0.5
        layout.spacingMode = .fixed(spacing: 10)
        layout.scrollDirection = .horizontal
        self.productCollectionView.collectionViewLayout = layout
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setUpImages(imageUrl: URL, imageView: UIImageView) {
       
        let scale = UIScreen.main.scale
        let resizingProcessor = DownsamplingImageProcessor(size: CGSize(width: imageView.bounds.size.width * scale, height: imageView.bounds.size.height * scale))
        imageView.kf.indicatorType = .none
        imageView.kf.setImage(with: imageUrl, placeholder: UIImage(named: "") , options: [
                .processor(resizingProcessor),
                .scaleFactor(UIScreen.main.scale),
                .cacheOriginalImage
            ]) { (_) in
            }
        
    }
   
}
extension HomeCarouselCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCollectionCell", for: indexPath) as? HomeCollectionCell
        {
            let productImage = imageArray[indexPath.row]
            self.setUpImages(imageUrl:  productImage, imageView: cell.productImage)
            return cell
        }
        return UICollectionViewCell()
    }
    
    
}
public var screenWidth: CGFloat {
    return UIScreen.main.bounds.width
}

// Screen height.
public var screenHeight: CGFloat {
    return UIScreen.main.bounds.height
}
