//
//  CategoryListCell.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import UIKit

class CategoryListCell: UICollectionViewCell {
    @IBOutlet weak var categoryImage: UIImageView!
    var cellData: CategorProduct?
}
