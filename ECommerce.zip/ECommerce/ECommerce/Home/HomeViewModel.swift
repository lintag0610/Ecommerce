//
//  HomeViewModel.swift
//  ECommerce
//
//  Created by LINTA GEORGE on 14/05/22.
//

import Foundation
protocol HomeUIUpdater: AnyObject {
    
    func loadHomeView()

}

class HomeViewModel {
    var offerList: [Offer] = []
    var bannerList: [Banner] = []
    var productsCategoryBased: [CategorProduct] = []
    weak var UpdateUIDelegate: HomeUIUpdater?
    fileprivate let webserviceManager = ECommerceWebServiceManager.shared
    
    func fetchDataForHomeScreen(loadFromAPI: Bool) {
        // Since Question Asks for a Backend Fetched Version Implemented
        if loadFromAPI == true {
        let dispatchGroup = DispatchGroup()
        dispatchGroup.enter()
        self.webserviceManager.getBanners(parameter: "home") {  [weak self] (header, result, error) in
            guard let weakSelf = self else { return }
            if error == nil {
                guard let recievedResult = result as? BannerResp else { return }
                weakSelf.bannerList = recievedResult.response?.banners ?? []
                dispatchGroup.leave()
            } else {
                dispatchGroup.leave()
            }
            
        }
        
        dispatchGroup.enter()
        self.webserviceManager.getOffers(parameter: "offers") {  [weak self] (header, result, error) in
            guard let weakSelf = self else { return }
            if error == nil {
                guard let recievedResult = result as? OfferResp else { return }
                weakSelf.offerList = recievedResult.response?.offers ?? []
                dispatchGroup.leave()
            } else {
                dispatchGroup.leave()
            }
            
        }
        
        dispatchGroup.enter()
        self.webserviceManager.getCategories(parameter: "getProducts") {  [weak self] (header, result, error) in
            guard let weakSelf = self else { return }
            if error == nil {
                guard let recievedResult = result as? CategoryproductResponse else { return }
                weakSelf.productsCategoryBased = recievedResult.response?.categoryBasedProducts ?? []
                dispatchGroup.leave()
            } else {
                dispatchGroup.leave()
            }
            
        }
        
        dispatchGroup.notify(queue: .main) {
            DispatchQueue.main.async {
            self.UpdateUIDelegate?.loadHomeView()
            }
        }
        } else {
            
            // URLS OF Images
            
            offerList = [Offer(offerId: "1", offerImage: "https://tinyurl.com/y3w8oaah"), Offer(offerId: "2", offerImage: "https://tinyurl.com/y4vaulog"),Offer(offerId: "3", offerImage: "https://tinyurl.com/y3j7rq6g"),Offer(offerId: "4", offerImage: "https://tinyurl.com/y28jpmyr"),Offer(offerId: "5", offerImage: "https://tinyurl.com/y2w7fbdo"), Offer(offerId: "6", offerImage: "https://tinyurl.com/yy2f6lha")]
            
            bannerList = [Banner(bannerId: "1", bannerImage: "https://tinyurl.com/y379jw6s"),Banner(bannerId: "2", bannerImage: "https://tinyurl.com/y3pjtea4"),Banner(bannerId: "3", bannerImage: "https://tinyurl.com/y2gersqn"),Banner(bannerId: "4", bannerImage: "https://tinyurl.com/y3c6ksu5"),Banner(bannerId: "5", bannerImage: "https://tinyurl.com/y4k2klen"),Banner(bannerId: "6", bannerImage: "https://tinyurl.com/y3pccdrc"), Banner(bannerId: "7", bannerImage: "https://tinyurl.com/y26fn9rm")]
            
            
            productsCategoryBased = [CategorProduct(categoryId: "1", categoryImage: "https://tinyurl.com/y4f5e96j",categoryDiscount: "Min 50 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "2", categoryImage: "https://tinyurl.com/y2szwrys",categoryDiscount: "Min 20 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "3", categoryImage: "https://tinyurl.com/y4bfj5b7",categoryDiscount: "Min 30 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "4", categoryImage: "https://tinyurl.com/y44marw5",categoryDiscount: "Min 50 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "5", categoryImage: "https://tinyurl.com/y4urobx8",categoryDiscount: "Min 60 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "6", categoryImage: "https://tinyurl.com/y2yhf95n",categoryDiscount: "Min 70 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "7", categoryImage: "https://tinyurl.com/y5n467o3",categoryDiscount: "Min 80 % Off" ,categorName: "Shirt"),CategorProduct(categoryId: "8", categoryImage: "https://tinyurl.com/yxupqdll",categoryDiscount: "Min 40 % Off" ,categorName: "Shirt")]
            
            self.UpdateUIDelegate?.loadHomeView()
        }
    
}
}
